package com.ancientextra;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import slimeknights.tconstruct.library.materials.stats.MaterialStatsId;
import slimeknights.tconstruct.library.tools.part.ToolPartItem;

@Mod(AncientExtra.MODID)
public class AncientExtra {
    public static final String MODID = "ancientextra";

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    /** Metal-only stat type: materials without plating stats (wood, stone, ...) are rejected. */
    private static final MaterialStatsId PLATING = new MaterialStatsId("tconstruct", "plating");

    /** Glass barrel: plain item (no material data), but tagged as a Tinkers part so the part chest takes it. */
    public static final RegistryObject<Item> GLASS_BARREL = ITEMS.register("glass_barrel",
            () -> new Item(new Item.Properties()));

    /** Swasher tank part (metal only). */
    public static final RegistryObject<Item> SWASHER_TANK = ITEMS.register("swasher_tank",
            () -> new ToolPartItem(new Item.Properties(), PLATING));

    /** Swasher barrel part (metal only). */
    public static final RegistryObject<Item> SWASHER_BARREL = ITEMS.register("swasher_barrel",
            () -> new ToolPartItem(new Item.Properties(), PLATING));

    /** Plain cast items: the casting table matches them through the tconstruct:casts tags. */
    public static final RegistryObject<Item> SWASHER_TANK_CAST = ITEMS.register("swasher_tank_cast",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> SWASHER_BARREL_CAST = ITEMS.register("swasher_barrel_cast",
            () -> new Item(new Item.Properties()));

    private static final String[] CONTENT = {
            "tinkersancient:battlesign_head",
            "tinkersancient:battlesign_handle",
            "tinkersancient:melting_pan_head",
            "tinkersancient:melting_pan_handle",
            "tinkersancient:war_pick_handle",
            "tinkersancient:war_pick_limb",
            "tinkersancient:battlesign_head_cast",
            "tinkersancient:battlesign_handle_cast",
            "tinkersancient:melting_pan_head_cast",
            "tinkersancient:melting_pan_handle_cast",
            "tinkersancient:war_pick_handle_cast",
            "tinkersancient:war_pick_limb_cast",
            "tinkersancient:battlesign",
            "tinkersancient:melting_pan",
            "tinkersancient:war_pick",
            "tconstruct:swasher"
    };

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    @SuppressWarnings("unchecked")
    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.ancientextra"))
            .icon(() -> new ItemStack(Items.GOLD_INGOT))
            .displayItems((params, output) -> {
                RegistryObject<Item>[] own = new RegistryObject[] {
                        GLASS_BARREL, SWASHER_TANK, SWASHER_BARREL, SWASHER_TANK_CAST, SWASHER_BARREL_CAST
                };
                for (RegistryObject<Item> entry : own) {
                    ItemStack stack = new ItemStack(entry.get());
                    if (!stack.isEmpty()) {
                        output.accept(stack);
                    }
                }
                for (String id : CONTENT) {
                    Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(id));
                    if (item != null) {
                        ItemStack stack = new ItemStack(item);
                        if (!stack.isEmpty()) {
                            output.accept(stack);
                        }
                    }
                }
            })
            .build());

    public AncientExtra() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
